import { UserInput, CalculationResult, YearlyProjection, Gender, Scenario } from '../types';

// Standard Living Costs (Monthly, in Man-won) - 2024 Estimates (Min. Cost of Living + Basic Consumption)
const BASE_LIVING_COSTS = {
  2: 220, // 2-person household
  3: 310, // 3-person household
  4: 400  // 4-person household
};

/**
 * Returns estimated MONTHLY additional medical costs (in Man-won) based on age.
 * Based on National Health Insurance Service (NHIS) 2022 Statistics.
 * Medical expenses rise significantly after age 65.
 * - 65~69: +25 Man-won (Basic geriatric care)
 * - 70~79: +45 Man-won (Chronic disease management)
 * - 80~89: +70 Man-won (Intensive care / partial nursing)
 * - 90+:   +100 Man-won (Long-term care / nursing home contribution)
 */
const getAgeBasedMedicalCost = (age: number): number => {
    if (age < 65) return 0;       
    if (age < 70) return 25;      
    if (age < 80) return 45;      
    if (age < 90) return 70;      
    return 100;                   
};

export const estimateLifeExpectancy = (birthYear: number, gender: Gender): number => {
  // Simple heuristic based on Korean actuarial trends
  // Base (1970 cohort approx): Male 75, Female 81 (Adjusted for "Expected" lifespan at 60)
  // Trend: +0.2 years per birth year
  const baseYear = 1970;
  const yearDiff = birthYear - baseYear;
  const improvement = yearDiff * 0.2;
  
  const baseExpectancy = gender === Gender.MALE ? 82 : 88; // 2024 approximation for retirement planning safety
  
  // Cap at 120 per user request
  return Math.round(Math.min(120, Math.max(70, baseExpectancy + improvement)));
};

/**
 * Calculates estimated severance pay based on the standard formula:
 * (Average Daily Wage * 30) * (Total Service Days / 365)
 * 
 * We assume 'monthlyIncome' represents the average monthly wage (approx 30 days of wages).
 * To be precise: Severance = (Average Monthly Wage) * (Continuous Service Days / 365)
 */
export const calculateCurrentSeverance = (monthlyIncome: number, workStartDate: string): number => {
  if (!workStartDate || !monthlyIncome) return 0;
  
  const start = new Date(workStartDate);
  const now = new Date();
  
  if (isNaN(start.getTime())) return 0;

  // Calculate total days of service
  const diffTime = now.getTime() - start.getTime();
  // Add 1 day inclusive
  const diffDays = (diffTime / (1000 * 60 * 60 * 24)) + 1; 
  
  // Legal standard: Roughly 1 month pay per 1 year (365 days) worked.
  const yearsWorkedExact = Math.max(0, diffDays / 365);
  
  return Math.round(monthlyIncome * yearsWorkedExact);
};

export const calculateProjections = (input: UserInput): CalculationResult => {
  const currentYear = new Date().getFullYear();
  const startYear = new Date(input.workStartDate).getFullYear();
  
  // Starting DB Value (Severance)
  const estimatedSeverance = input.currentEstimatedSeverance > 0 
    ? input.currentEstimatedSeverance 
    : calculateCurrentSeverance(input.currentMonthlyIncome, input.workStartDate);

  const projections: YearlyProjection[] = [];
  const yearsUntilRetirement = input.retirementAge - (currentYear - input.birthYear);
  const lifeExpectancy = input.lifeExpectancy;
  const yearsUntilDeath = lifeExpectancy - (currentYear - input.birthYear);

  // Initialize state variables
  let currentMonthlySalary = input.currentMonthlyIncome;
  
  // Base living cost starts at year 0 value
  let currentMonthlyBaseLivingCost = BASE_LIVING_COSTS[input.familySize] || 300;
  
  // "Private Savings" bucket
  let dbPrivateSavings = 0;
  
  // Initial Wealth
  const initialWealth = estimatedSeverance + input.otherAssets;

  // Add Year 0
  projections.push({
    year: currentYear,
    age: currentYear - input.birthYear,
    salary: currentMonthlySalary,
    monthlyLivingCost: Math.round(currentMonthlyBaseLivingCost),
    livingCost: Math.round(currentMonthlyBaseLivingCost * 12), 
    investableSurplus: 0,
    dbValue: initialWealth,
    scenario1Value: initialWealth, 
    scenario2Value: initialWealth,
    scenario3Value: initialWealth,
    scenario4Value: initialWealth,
  });

  // Helper to get variable return rate based on elapsed years (0-5, 6-10, 11+)
  const getReturnRate = (rates: number[], yearIndex: number) => {
    if (yearIndex < 5) return rates[0];
    if (yearIndex < 10) return rates[1];
    return rates[2];
  };

  // Loop until Life Expectancy (Death)
  for (let i = 1; i <= yearsUntilDeath; i++) {
    const year = currentYear + i;
    const age = (currentYear - input.birthYear) + i;
    const serviceYears = (year - startYear);
    const isRetired = i > yearsUntilRetirement;

    // 1. Grow Salary & Base Living Cost
    if (!isRetired) {
        currentMonthlySalary = currentMonthlySalary * (1 + input.expectedWageGrowthRate / 100);
    } else {
        currentMonthlySalary = 0; 
    }
    
    // Inflate the base living cost (general inflation)
    currentMonthlyBaseLivingCost = currentMonthlyBaseLivingCost * (1 + input.inflationRate / 100);

    // 2. Calculate Age-Based Medical Cost (NHIS Data)
    // We get the base medical cost for this age in today's money (PV)
    const baseMedicalCostPV = getAgeBasedMedicalCost(age);
    
    // We inflate this specific medical portion to Future Value (FV)
    // Medical inflation often outpaces CPI, but here we use the user-defined general inflation rate for consistency,
    // or we could add a spread (e.g. +1%) if we wanted to be more precise, but sticking to general inflation is safe.
    const inflatedMedicalCost = baseMedicalCostPV * Math.pow(1 + input.inflationRate / 100, i);

    // Total Living Cost = Base + Medical
    const totalMonthlyLivingCost = currentMonthlyBaseLivingCost + inflatedMedicalCost;

    // 3. Calculate Investable Surplus (Annual) or Deficit (Living Cost)
    let annualSurplus = 0;
    let annualLivingCostDeduction = 0;

    if (!isRetired) {
        // Working phase: Income - Cost > 0 -> Invest
        const monthlySurplus = Math.max(0, currentMonthlySalary - totalMonthlyLivingCost);
        annualSurplus = monthlySurplus * 12;
    } else {
        // Retirement phase: Cost is a deduction from assets (Drawdown)
        annualLivingCostDeduction = totalMonthlyLivingCost * 12;
    }

    // 4. Calculate Pure DB Value (Pension Only)
    let dbPensionValue = 0;
    if (!isRetired) {
         dbPensionValue = currentMonthlySalary * serviceYears;
    } 

    // Helper to calculate next step for a scenario
    const calculateNextWealth = (
      prevTotalWealth: number,
      scenarioIndex: number, // -1 for DB
      prevDbPensionOnly: number
    ) => {
       const scenario = scenarioIndex >= 0 ? input.scenarios[scenarioIndex] : input.scenarios[0]; 
       const rate = getReturnRate(scenario.returnRates, i);
       const effectiveReturnRate = rate - input.managementFee; 

       // --- RETIREMENT PHASE ---
       if (isRetired) {
           if (prevTotalWealth <= 0) return 0;

           const growth = prevTotalWealth * (effectiveReturnRate / 100);
           return Math.max(0, prevTotalWealth + growth - annualLivingCostDeduction);
       }

       // --- WORKING PHASE ---
       if (scenarioIndex === -1) {
           // DB Scenario
           const marketGrowth = dbPrivateSavings * (effectiveReturnRate / 100);
           return dbPensionValue + (dbPrivateSavings + marketGrowth + annualSurplus) + input.otherAssets;
       }

       const s = input.scenarios[scenarioIndex];

       // Before Switch (DB Mode)
       if (year < s.switchYear) {
           return dbPensionValue + (dbPrivateSavings + (dbPrivateSavings * (effectiveReturnRate / 100)) + annualSurplus) + input.otherAssets;
       }
       
       // At Switch Year
       if (year === s.switchYear) {
           return dbPensionValue + (dbPrivateSavings + (dbPrivateSavings * (effectiveReturnRate / 100)) + annualSurplus) + input.otherAssets;
       }

       // After Switch (DC Mode)
       const investmentGrowth = prevTotalWealth * (effectiveReturnRate / 100);
       const employerContribution = currentMonthlySalary; 
       
       return prevTotalWealth + investmentGrowth + employerContribution + annualSurplus;
    };

    const prevProj = projections[projections.length - 1];

    // Update DB Private Savings for the DB Scenario logic
    const marketRate = getReturnRate(input.scenarios[0].returnRates, i); 
    const effectiveMarketRate = Math.max(0, marketRate - input.managementFee);
    const dbSavingsGrowth = dbPrivateSavings * (effectiveMarketRate / 100);
    
    if (!isRetired) {
        dbPrivateSavings = dbPrivateSavings + dbSavingsGrowth + annualSurplus;
    }

    const valDB = calculateNextWealth(prevProj.dbValue, -1, dbPensionValue);
    const val1 = calculateNextWealth(prevProj.scenario1Value, 0, dbPensionValue);
    const val2 = calculateNextWealth(prevProj.scenario2Value, 1, dbPensionValue);
    const val3 = calculateNextWealth(prevProj.scenario3Value, 2, dbPensionValue);
    const val4 = calculateNextWealth(prevProj.scenario4Value, 3, dbPensionValue);

    projections.push({
      year,
      age,
      salary: Math.round(currentMonthlySalary),
      monthlyLivingCost: Math.round(totalMonthlyLivingCost),
      livingCost: Math.round(totalMonthlyLivingCost * 12),
      investableSurplus: Math.round(isRetired ? -annualLivingCostDeduction : annualSurplus),
      dbValue: Math.round(valDB), 
      scenario1Value: Math.round(val1),
      scenario2Value: Math.round(val2),
      scenario3Value: Math.round(val3),
      scenario4Value: Math.round(val4),
    });
  }

  // Find Depletion Ages
  const findDepletionAge = (key: keyof YearlyProjection) => {
      const emptyYear = projections.find(p => p[key] <= 0 && p.age >= input.retirementAge);
      return emptyYear ? emptyYear.age : '유지';
  };

  const final = projections[projections.length - 1];
  const retirementYearProj = projections.find(p => p.age === input.retirementAge) || final;
  const taxMultiplier = 1 - (input.taxRate / 100);
  const finalDBAfterTax = Math.round(retirementYearProj.dbValue * taxMultiplier);

  const results = [
    { id: 0, label: 'DB 유지', amount: retirementYearProj.dbValue }, 
    { id: 1, label: input.scenarios[0].label, amount: retirementYearProj.scenario1Value },
    { id: 2, label: input.scenarios[1].label, amount: retirementYearProj.scenario2Value },
    { id: 3, label: input.scenarios[2].label, amount: retirementYearProj.scenario3Value },
    { id: 4, label: input.scenarios[3].label, amount: retirementYearProj.scenario4Value },
  ];
  results.sort((a, b) => b.amount - a.amount);

  return {
    projections,
    summary: {
      finalYear: final.year,
      totalYearsWorked: input.retirementAge - (startYear - input.birthYear), 
      finalSalary: retirementYearProj.salary,
      finalDB: retirementYearProj.dbValue, 
      finalDBAfterTax,
      totalInvestedSurplus: dbPrivateSavings,
      postRetirementYears: lifeExpectancy - input.retirementAge,
      scenarios: input.scenarios.map((s, idx) => {
        const key = `scenario${idx+1}Value` as keyof YearlyProjection;
        const valAtRetirement = (retirementYearProj as any)[key];
        
        return {
          id: s.id,
          label: s.label,
          finalAmount: valAtRetirement, 
          finalAmountAfterTax: Math.round(valAtRetirement * taxMultiplier),
          avgReturnRate: (s.returnRates[0] + s.returnRates[1] + s.returnRates[2]) / 3,
          switchYear: s.switchYear,
          riskLevel: s.riskLevel,
          depletionAge: findDepletionAge(key)
        };
      }),
      bestOption: results[0].label,
    }
  };
};

export const optimizeScenarios = (input: UserInput): Scenario[] => {
    const currentYear = new Date().getFullYear();
    const retirementYear = input.birthYear + input.retirementAge;
    const maxSwitchYear = Math.max(currentYear, retirementYear);

    return input.scenarios.map((scenario) => {
        let bestYear = currentYear;
        let maxFinalAmount = -1;

        for (let year = currentYear; year <= maxSwitchYear; year++) {
            const tempInput: UserInput = {
                ...input,
                scenarios: input.scenarios.map(s => 
                    s.id === scenario.id ? { ...s, switchYear: year } : s
                )
            };

            const result = calculateProjections(tempInput);
            const summary = result.summary.scenarios.find(s => s.id === scenario.id);
            
            if (summary && summary.finalAmount > maxFinalAmount) {
                maxFinalAmount = summary.finalAmount;
                bestYear = year;
            }
        }

        return {
            ...scenario,
            switchYear: bestYear
        };
    });
};