import { GoogleGenAI } from "@google/genai";
import { UserInput, CalculationResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiAdvice = async (input: UserInput, result: CalculationResult): Promise<string> => {
  const scenarioText = result.summary.scenarios.map(s => 
    `- ${s.label} (${s.switchYear}년 전환, ${s.riskLevel}): 은퇴 시점 자산 ${Math.round(s.finalAmount/10000)}억원 (자산 고갈 시점: ${s.depletionAge}세)`
  ).join('\n');

  const postRetirementYears = input.lifeExpectancy - input.retirementAge;
  const bestScenario = result.summary.scenarios.find(s => s.label === result.summary.bestOption) || { finalAmount: result.summary.finalDB };

  const prompt = `
    [페르소나 설정]
    당신은 "갑부요정"이라는 캐릭터입니다.
    부자가 되고 싶은 사람들을 도와주는 40대 전문 재무 컨설턴트 요정입니다.
    
    [말투 가이드]
    - "안녕? 난 갑부요정이야~ 🧚‍♀️" 처럼 친근하게 시작하지 않아도 됩니다. (UI에 이미 표시됨)
    - 분석 내용은 매우 전문적이고 날카로워야 합니다.
    - 하지만 어미는 친절한 '해요'체를 사용하며, 걱정스러운 부분은 진심으로 우려를 표합니다.
    - 예: "이대로 가면 80세엔 돈이 바닥나요. 정말 큰일이에요! 😭" 
    - 이모지를 적절히 사용하여 감정을 표현하세요.

    [분석 대상 정보]
    - 사용자: ${input.nickname ? `'${input.nickname}'` : '사용자'}님, ${input.birthYear}년생 ${input.gender}, ${input.familySize}인 가구
    - 소득/지출: 월 ${input.currentMonthlyIncome}만원 소득, 생활비 및 물가상승(${input.inflationRate}%) 반영됨
    - 은퇴 계획: ${input.retirementAge}세 은퇴, 기대수명 ${input.lifeExpectancy}세 (은퇴 후 ${postRetirementYears}년 소득 없이 생존)
    - 시뮬레이션 전제: 은퇴 후에는 근로 소득이 0원이며, 모아둔 자산을 생활비로 헐어 씁니다. (의료비 증가 반영됨)

    [시뮬레이션 결과 요약]
    1. DB 유지 시 은퇴 자산: ${Math.round(result.summary.finalDB/10000)}억원
    ${scenarioText}
    
    [가장 유리한 전략]
    "${result.summary.bestOption}" (예상 자산 약 ${Math.round(bestScenario.finalAmount/10000)}억원)

    [요청사항]
    위 정보를 바탕으로 아래 3가지 항목에 대해 마크다운 형식으로 분석 리포트를 작성해주세요. 
    각 섹션의 제목은 반드시 '###' (H3) 헤더를 사용해주세요.

    ### 🚨 냉철한 현실 점검
    은퇴 후 ${postRetirementYears}년 동안 자산이 유지될지, 아니면 중간에 고갈될 위험이 있는지 확인하세요. 
    특히 노년기 의료비 증가를 감당할 수 있을지 "갑부요정"의 시선으로 걱정스럽게 지적해주세요.

    ### 📉 투자 성향 진단
    사용자가 선택한 투자 성향(수익률)이 너무 낮아서 손해인지, 혹은 너무 높아서(10~15%) 위험한지 평가하세요.

    ### 💡 요정의 솔루션
    가장 유리한 전환 시점과 구체적인 액션 플랜을 딱 정해주세요.

    글자 수는 600자 이내로, 가독성 좋게 작성해주세요.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "죄송해요, 마법 구슬이 흐려서 분석 결과를 가져오지 못했어요 😭";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "요정님과 연결이 끊겼어요! 잠시 후 다시 시도해 주세요.";
  }
};