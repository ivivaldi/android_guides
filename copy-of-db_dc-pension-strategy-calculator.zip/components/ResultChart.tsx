
import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Label,
  DotProps
} from 'recharts';
import { YearlyProjection, Scenario } from '../types';

interface ResultChartProps {
  data: YearlyProjection[];
  scenarios: Scenario[];
  birthYear: number;
  retirementAge: number;
}

// Custom Dot Component to render marker only at the switch year
const SwitchDot = (props: any, switchYear: number, stroke: string) => {
  const { cx, cy, payload } = props;
  if (payload.year === switchYear) {
    return (
      <g>
        <circle cx={cx} cy={cy} r={6} fill={stroke} stroke="white" strokeWidth={2} />
        <circle cx={cx} cy={cy} r={3} fill="white" />
      </g>
    );
  }
  return null;
};

export const ResultChart: React.FC<ResultChartProps> = ({ data, scenarios, birthYear, retirementAge }) => {
  const retirementYear = birthYear + retirementAge;
  const year70 = birthYear + 70;
  const year80 = birthYear + 80;
  const year90 = birthYear + 90;

  // Filter data to ensure we cover the range but handle empty projections gracefully
  const maxYear = data.length > 0 ? data[data.length - 1].year : 0;

  // Calculate Max Value for Dynamic Y-Axis Scaling
  const maxAssetValue = Math.max(
    ...data.map(d => Math.max(d.dbValue, d.scenario1Value, d.scenario2Value, d.scenario3Value, d.scenario4Value))
  );
  
  // Add 10% padding to the max value for better visualization
  const yDomainMax = Math.ceil(maxAssetValue * 1.1);

  return (
    <div className="h-96 w-full mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 20,
            right: 20,
            left: 0,
            bottom: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
          <XAxis 
            dataKey="year" 
            tick={{fontSize: 11}} 
            tickMargin={10}
            padding={{ left: 10, right: 10 }}
          />
          
          {/* Left Axis: Total Assets (Dynamic Domain) */}
          <YAxis 
            yAxisId="left"
            tickFormatter={(value) => `${(value / 10000).toFixed(0)}억`} 
            width={40}
            tick={{fontSize: 11}}
            domain={[0, yDomainMax]}
          />

          {/* Right Axis: Monthly Living Cost */}
          <YAxis 
            yAxisId="right"
            orientation="right"
            tickFormatter={(value) => `${(value).toLocaleString()}만`}
            width={40}
            tick={{fontSize: 10, fill: '#ef4444'}}
            domain={['auto', 'auto']}
          />

          <Tooltip 
            formatter={(value: number, name: string) => {
                if (name === '생활비') return [`${value.toLocaleString()} 만원 (월)`, name];
                return [`${(value/10000).toFixed(1)} 억원 (${value.toLocaleString()} 만원)`, name];
            }}
            labelFormatter={(label) => `${label}년 (${label - birthYear}세)`}
            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
          />
          <Legend wrapperStyle={{ paddingTop: '10px', fontSize: '12px' }} />
          
          {/* Reference Lines for Ages */}
          {retirementYear <= maxYear && (
            <ReferenceLine x={retirementYear} stroke="black" strokeWidth={1.5} yAxisId="left">
                <Label value="은퇴" position="insideTopLeft" fill="black" fontSize={11} fontWeight="bold" />
            </ReferenceLine>
          )}
          {year70 <= maxYear && (
             <ReferenceLine x={year70} stroke="#9ca3af" strokeDasharray="3 3" yAxisId="left">
                 <Label value="70세" position="insideTop" fill="#6b7280" fontSize={10} />
             </ReferenceLine>
          )}
          {year80 <= maxYear && (
             <ReferenceLine x={year80} stroke="#9ca3af" strokeDasharray="3 3" yAxisId="left">
                 <Label value="80세" position="insideTop" fill="#6b7280" fontSize={10} />
             </ReferenceLine>
          )}
          {year90 <= maxYear && (
             <ReferenceLine x={year90} stroke="#9ca3af" strokeDasharray="3 3" yAxisId="left">
                 <Label value="90세" position="insideTop" fill="#6b7280" fontSize={10} />
             </ReferenceLine>
          )}

          {/* Asset Lines with Switch Points */}
          <Line 
            yAxisId="left" 
            type="monotone" 
            dataKey="dbValue" 
            name="DB 유지" 
            stroke="#6b7280" 
            strokeWidth={2} 
            strokeDasharray="5 5" 
            dot={false} 
          />
          
          <Line 
            yAxisId="left" 
            type="monotone" 
            dataKey="scenario1Value" 
            name={scenarios[0].label} 
            stroke="#2563eb" 
            strokeWidth={2} 
            dot={(props) => SwitchDot(props, scenarios[0].switchYear, "#2563eb")}
            activeDot={{ r: 6 }}
          />
          <Line 
            yAxisId="left" 
            type="monotone" 
            dataKey="scenario2Value" 
            name={scenarios[1].label} 
            stroke="#16a34a" 
            strokeWidth={2} 
            dot={(props) => SwitchDot(props, scenarios[1].switchYear, "#16a34a")}
            activeDot={{ r: 6 }}
          />
          <Line 
            yAxisId="left" 
            type="monotone" 
            dataKey="scenario3Value" 
            name={scenarios[2].label} 
            stroke="#d97706" 
            strokeWidth={2} 
            dot={(props) => SwitchDot(props, scenarios[2].switchYear, "#d97706")}
            activeDot={{ r: 6 }}
          />
          <Line 
            yAxisId="left" 
            type="monotone" 
            dataKey="scenario4Value" 
            name={scenarios[3].label} 
            stroke="#7c3aed" 
            strokeWidth={2} 
            dot={(props) => SwitchDot(props, scenarios[3].switchYear, "#7c3aed")}
            activeDot={{ r: 6 }}
          />

          {/* Living Cost Line (Monthly) */}
          <Line 
            yAxisId="right" 
            type="monotone" 
            dataKey="monthlyLivingCost" 
            name="생활비" 
            stroke="#ef4444" 
            strokeWidth={1} 
            strokeDasharray="2 2" 
            dot={false} 
            opacity={0.7}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
