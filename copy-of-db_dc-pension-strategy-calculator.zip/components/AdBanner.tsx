import React, { useEffect, useRef } from 'react';

interface AdBannerProps {
  className?: string;
  dataAdSlot?: string; // 광고 단위 ID (없으면 플레이스홀더 표시)
  dataAdFormat?: string;
  dataFullWidthResponsive?: boolean;
}

export const AdBanner: React.FC<AdBannerProps> = ({ 
  className = "", 
  dataAdSlot = "", // 테스트를 위해 비워둠. 실제 운영 시 발급받은 Slot ID 입력
  dataAdFormat = "auto", 
  dataFullWidthResponsive = true 
}) => {
  const adRef = useRef<HTMLModElement>(null);

  useEffect(() => {
    // 실제 AdSense 스크립트가 로드되었고, Slot ID가 있을 때만 광고 요청
    if (dataAdSlot && window.adsbygoogle && adRef.current) {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (e) {
        console.error("AdSense error", e);
      }
    }
  }, [dataAdSlot]);

  // 광고 ID가 없을 때 (개발/테스트 모드) 보여줄 플레이스홀더
  if (!dataAdSlot) {
    return (
      <div className={`w-full bg-gray-100 border border-gray-300 border-dashed rounded-lg flex flex-col items-center justify-center p-4 text-gray-400 text-xs ${className}`}>
        <span className="font-bold mb-1">광고 영역 (Google AdSense)</span>
        <span>ca-pub-ID 및 data-ad-slot ID를 설정하면 광고가 표시됩니다.</span>
      </div>
    );
  }

  return (
    <div className={`w-full overflow-hidden ${className}`}>
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXX" // index.html과 동일한 본인 ID 입력
        data-ad-slot={dataAdSlot}
        data-ad-format={dataAdFormat}
        data-full-width-responsive={dataFullWidthResponsive ? "true" : "false"}
        ref={adRef}
      />
    </div>
  );
};

// Window 객체 타입 확장
declare global {
  interface Window {
    adsbygoogle: any[];
  }
}