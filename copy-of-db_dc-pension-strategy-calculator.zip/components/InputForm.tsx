import React from 'react';
import { UserInput, Gender, Scenario, RiskLevel } from '../types';
import { estimateLifeExpectancy, calculateCurrentSeverance, optimizeScenarios } from '../services/calculationService';

interface InputFormProps {
  input: UserInput;
  onChange: (input: UserInput) => void;
  onCalculate: () => void;
  onSave: () => void;
  onLoad: () => void;
}

// Risk Presets
const RISK_PRESETS = {
  [RiskLevel.CONSERVATIVE]: 4,
  [RiskLevel.MODERATE]: 7,
  [RiskLevel.AGGRESSIVE]: 10, // Updated to 10% as requested
  [RiskLevel.CUSTOM]: 0
};

export const InputForm: React.FC<InputFormProps> = ({ input, onChange, onCalculate, onSave, onLoad }) => {
  const currentYear = new Date().getFullYear();

  // Smart Change Handler
  const handleChange = (field: keyof UserInput, value: any) => {
    const updates: Partial<UserInput> = { [field]: value };
    
    // 1. Auto-update Life Expectancy
    if (field === 'birthYear' || field === 'gender') {
        const bYear = field === 'birthYear' ? value : input.birthYear;
        const gen = field === 'gender' ? value : input.gender;
        updates.lifeExpectancy = estimateLifeExpectancy(bYear, gen);
    }

    // 2. Auto-update Severance
    if (field === 'currentMonthlyIncome' || field === 'workStartDate') {
        const income = field === 'currentMonthlyIncome' ? value : input.currentMonthlyIncome;
        const start = field === 'workStartDate' ? value : input.workStartDate;
        updates.currentEstimatedSeverance = calculateCurrentSeverance(income, start);
    }
    
    onChange({ ...input, ...updates });
  };

  const handleScenarioChange = (index: number, field: keyof Scenario, value: any) => {
    const newScenarios = [...input.scenarios];
    newScenarios[index] = { ...newScenarios[index], [field]: value };
    handleChange('scenarios', newScenarios);
  };

  const handleRiskLevelSelect = (scenarioIndex: number, level: RiskLevel) => {
    if (level === RiskLevel.CUSTOM) return;
    
    const rate = RISK_PRESETS[level];
    const newScenarios = [...input.scenarios];
    newScenarios[scenarioIndex] = { 
        ...newScenarios[scenarioIndex], 
        riskLevel: level,
        returnRates: [rate, rate, rate] 
    };
    onChange({ ...input, scenarios: newScenarios });
  };

  const handleReturnRateChange = (scenarioIndex: number, rateIndex: number, value: number) => {
    const newScenarios = [...input.scenarios];
    const newRates = [...newScenarios[scenarioIndex].returnRates];
    newRates[rateIndex] = value;
    newScenarios[scenarioIndex] = { 
        ...newScenarios[scenarioIndex], 
        returnRates: newRates,
        riskLevel: RiskLevel.CUSTOM 
    };
    onChange({ ...input, scenarios: newScenarios });
  };

  const handleOptimize = () => {
    const optimizedScenarios = optimizeScenarios(input);
    handleChange('scenarios', optimizedScenarios);
    alert('각 시나리오의 설정된 수익률을 바탕으로 최적의 전환 시점이 적용되었습니다.');
  };

  return (
    <div className="bg-white p-5 rounded-xl shadow-2xl space-y-5">
      {/* Header Actions */}
      <div className="flex justify-between items-center border-b border-gray-100 pb-3">
        <h2 className="text-sm font-bold text-gray-500">기본 설정</h2>
        <div className="flex space-x-3">
            <button onClick={onSave} className="flex items-center space-x-1 text-xs font-bold text-gray-500 hover:text-indigo-600 transition-colors">
                <span>💾 설정 저장</span>
            </button>
            <span className="text-gray-300">|</span>
            <button onClick={onLoad} className="flex items-center space-x-1 text-xs font-bold text-gray-500 hover:text-indigo-600 transition-colors">
                <span>📂 불러오기</span>
            </button>
        </div>
      </div>

      {/* 3-Column Compact Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* 1. Basic Info */}
          <section className="bg-gray-50 p-3.5 rounded-xl border border-gray-100">
            <h2 className="text-sm font-bold text-gray-800 mb-3 flex items-center">
                <span className="bg-gray-800 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] mr-2">1</span>
                기본 정보
            </h2>
            <div className="space-y-3">
                <div>
                    <label className="text-[11px] font-bold text-gray-600 block mb-1">별명</label>
                    <input
                        type="text"
                        value={input.nickname}
                        onChange={(e) => handleChange('nickname', e.target.value)}
                        className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none"
                        placeholder="예: 미래부자"
                    />
                    <p className="text-[9px] text-gray-400 mt-1">분석 리포트에서 호칭으로 사용됩니다.</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">출생연도</label>
                        <input
                            type="number"
                            value={input.birthYear}
                            onChange={(e) => handleChange('birthYear', parseInt(e.target.value))}
                            className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none"
                        />
                    </div>
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">성별</label>
                        <div className="flex rounded border border-gray-300 overflow-hidden">
                            <button
                                onClick={() => handleChange('gender', Gender.MALE)}
                                className={`flex-1 py-2 text-[10px] font-medium ${input.gender === Gender.MALE ? 'bg-indigo-100 text-indigo-700' : 'bg-white text-gray-500'}`}
                            >남</button>
                            <button
                                onClick={() => handleChange('gender', Gender.FEMALE)}
                                className={`flex-1 py-2 text-[10px] font-medium ${input.gender === Gender.FEMALE ? 'bg-pink-100 text-pink-700' : 'bg-white text-gray-500 border-l'}`}
                            >여</button>
                        </div>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">은퇴 나이</label>
                        <div className="relative">
                            <input
                                type="number"
                                value={input.retirementAge}
                                onChange={(e) => handleChange('retirementAge', parseInt(e.target.value))}
                                className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none text-right pr-6"
                            />
                            <span className="absolute right-2 top-2 text-[10px] text-gray-400">세</span>
                        </div>
                        <p className="text-[9px] text-gray-400 mt-1">소득이 중단되는 시점</p>
                    </div>
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">기대 수명</label>
                        <div className="relative">
                            <input
                                type="number" max={120}
                                value={input.lifeExpectancy}
                                onChange={(e) => handleChange('lifeExpectancy', parseInt(e.target.value))}
                                className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none text-right pr-6"
                            />
                            <span className="absolute right-2 top-2 text-[10px] text-gray-400">세</span>
                        </div>
                        <p className="text-[9px] text-gray-400 mt-1">자산이 유지되어야 할 나이</p>
                    </div>
                </div>
            </div>
          </section>

          {/* 2. Employment & Assets */}
          <section className="bg-gray-50 p-3.5 rounded-xl border border-gray-100">
            <h2 className="text-sm font-bold text-gray-800 mb-3 flex items-center">
                <span className="bg-gray-800 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] mr-2">2</span>
                소득 및 자산
            </h2>
            <div className="space-y-3">
                <div>
                    <label className="text-[11px] font-bold text-gray-600 block mb-1">근무 시작일</label>
                    <input
                        type="date"
                        value={input.workStartDate}
                        onChange={(e) => handleChange('workStartDate', e.target.value)}
                        className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none"
                    />
                     <p className="text-[9px] text-gray-400 mt-1">근속연수 계산 기준일</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">월 소득(만원)</label>
                        <input
                            type="number"
                            value={input.currentMonthlyIncome}
                            onChange={(e) => handleChange('currentMonthlyIncome', parseInt(e.target.value))}
                            className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none text-right"
                        />
                    </div>
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">가구원 수</label>
                        <select 
                            value={input.familySize}
                            onChange={(e) => handleChange('familySize', parseInt(e.target.value))}
                            className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none"
                        >
                            <option value={2}>2인</option>
                            <option value={3}>3인</option>
                            <option value={4}>4인</option>
                        </select>
                         <p className="text-[9px] text-gray-400 mt-1">기본 생활비 추정용</p>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">예상 퇴직금(만원)</label>
                        <input
                            type="number"
                            value={input.currentEstimatedSeverance}
                            onChange={(e) => handleChange('currentEstimatedSeverance', parseInt(e.target.value))}
                            className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none bg-gray-100 text-right"
                        />
                        <p className="text-[9px] text-gray-400 mt-1">현재 기준 정산 추정액</p>
                    </div>
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">기타 자산(만원)</label>
                        <input
                            type="number"
                            value={input.otherAssets}
                            onChange={(e) => handleChange('otherAssets', parseInt(e.target.value))}
                            className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none text-right"
                            placeholder="만원"
                        />
                        <p className="text-[9px] text-gray-400 mt-1">은퇴 시점에 더할 저축액</p>
                    </div>
                </div>
            </div>
          </section>

          {/* 3. Costs & Taxes & Inflation */}
          <section className="bg-gray-50 p-3.5 rounded-xl border border-gray-100">
            <h2 className="text-sm font-bold text-gray-800 mb-3 flex items-center">
                <span className="bg-gray-800 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] mr-2">3</span>
                물가/비용
            </h2>
            <div className="space-y-3">
                <div>
                    <label className="text-[11px] font-bold text-gray-600 block mb-1">물가상승률(%)</label>
                    <input
                        type="number" step="0.1"
                        value={input.inflationRate}
                        onChange={(e) => handleChange('inflationRate', parseFloat(e.target.value))}
                        className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none text-right"
                    />
                    <p className="text-[9px] text-gray-400 mt-1">매년 생활비 증가 비율 (최근 2.6%)</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">운용수수료(%)</label>
                        <input
                            type="number" step="0.01"
                            value={input.managementFee}
                            onChange={(e) => handleChange('managementFee', parseFloat(e.target.value))}
                            className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none text-right"
                        />
                        <p className="text-[9px] text-gray-400 mt-1">DC 상품 운용 비용</p>
                    </div>
                    <div>
                        <label className="text-[11px] font-bold text-gray-600 block mb-1">소득세율(%)</label>
                        <input
                            type="number" step="0.1"
                            value={input.taxRate}
                            onChange={(e) => handleChange('taxRate', parseFloat(e.target.value))}
                            className="w-full p-2 text-xs border border-gray-300 rounded focus:border-indigo-500 outline-none text-right"
                        />
                        <p className="text-[9px] text-gray-400 mt-1">퇴직소득세 예상율</p>
                    </div>
                </div>
            </div>
          </section>
      </div>

      {/* 4. Scenarios */}
      <section className="bg-white pt-4 border-t border-gray-100">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-sm font-bold text-gray-800 flex items-center">
                <span className="bg-gray-800 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] mr-2">4</span>
                시나리오 설정
            </h2>
            <button 
                onClick={handleOptimize}
                className="text-[10px] bg-indigo-50 text-indigo-600 px-3 py-1.5 rounded-full border border-indigo-100 hover:bg-indigo-100 font-bold transition-colors flex items-center shadow-sm"
            >
                ✨ 추천 시점 적용
            </button>
        </div>
        
        {/* Wage Growth Slider */}
        <div className="mb-6 px-2 bg-blue-50/50 p-3 rounded-lg border border-blue-100">
            <div className="flex justify-between items-end mb-2">
                <label className="text-[11px] font-bold text-blue-800">예상 임금 상승률</label>
                <span className="text-xs font-bold text-blue-600">{input.expectedWageGrowthRate}%</span>
            </div>
            <input 
                type="range" min="1" max="10" step="0.1"
                value={input.expectedWageGrowthRate}
                onChange={(e) => handleChange('expectedWageGrowthRate', parseFloat(e.target.value))}
                className="w-full h-1.5 bg-blue-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <p className="text-[9px] text-blue-400 mt-1.5">매년 연봉이 이 비율만큼 오른다고 가정합니다. (고용노동부 평균 3.5%)</p>
        </div>

        {/* Scenarios Grid */}
        <div className="space-y-4">
            {input.scenarios.map((scenario, sIndex) => {
              const showVariableSliders = sIndex >= 2; 

              return (
                <div key={scenario.id} className="bg-gray-50 p-3 rounded-lg border border-gray-200 shadow-sm">
                    <div className="flex justify-between items-center mb-3">
                        <span className="font-bold text-gray-700 text-xs flex items-center">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mr-2"></span>
                            {scenario.label}
                        </span>
                        <div className="text-[10px] text-gray-500 bg-white px-2 py-1 rounded border border-gray-200 font-mono">
                            {scenario.switchYear}년 전환
                        </div>
                    </div>

                    {/* Risk Level Selector */}
                    <div className="flex space-x-1 mb-3">
                        {[RiskLevel.CONSERVATIVE, RiskLevel.MODERATE, RiskLevel.AGGRESSIVE].map((level) => {
                             const isSelected = scenario.riskLevel === level;
                             let colorClass = "";
                             let label = "";
                             if (level === RiskLevel.CONSERVATIVE) {
                                 colorClass = isSelected ? "bg-blue-600 text-white shadow-md" : "bg-white text-gray-500 border border-gray-200 hover:bg-gray-50";
                                 label = "안정(4%)";
                             } else if (level === RiskLevel.MODERATE) {
                                 colorClass = isSelected ? "bg-green-600 text-white shadow-md" : "bg-white text-gray-500 border border-gray-200 hover:bg-gray-50";
                                 label = "중립(7%)";
                             } else {
                                 colorClass = isSelected ? "bg-red-500 text-white shadow-md" : "bg-white text-gray-500 border border-gray-200 hover:bg-gray-50";
                                 label = "공격(10%)"; // Updated label
                             }

                             return (
                                <button
                                    key={level}
                                    onClick={() => handleRiskLevelSelect(sIndex, level)}
                                    className={`flex-1 py-1.5 rounded text-[10px] font-medium transition-all ${colorClass}`}
                                >
                                    {label}
                                </button>
                             );
                        })}
                    </div>

                    {showVariableSliders ? (
                      <div className="bg-white p-2.5 rounded border border-gray-100">
                         <div className="flex justify-between items-center mb-2">
                            <p className="text-[10px] text-gray-400">기간별 수익률 (최대 15%)</p>
                            <span className="text-[9px] text-gray-300">0-5년 / 6-10년 / 11년+</span>
                         </div>
                         <div className="grid grid-cols-3 gap-3">
                            {[0, 1, 2].map((period) => (
                               <div key={period} className="flex flex-col items-center">
                                  <span className="text-[10px] font-bold text-gray-600 mb-1">{scenario.returnRates[period]}%</span>
                                  <input 
                                      type="range" min="3" max="15" step="0.5"
                                      value={scenario.returnRates[period]}
                                      onChange={(e) => handleReturnRateChange(sIndex, period, parseFloat(e.target.value))}
                                      className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-gray-500"
                                  />
                               </div>
                             ))}
                         </div>
                      </div>
                    ) : (
                      <div className="bg-white p-2.5 rounded border border-gray-100 flex items-center space-x-3">
                        <div className="w-16">
                            <span className="text-[10px] text-gray-500 block">목표 수익률</span>
                            <span className="text-[9px] text-gray-300 block">(최대 15%)</span>
                        </div>
                        <input 
                            type="range" min="3" max="15" step="0.5"
                            value={scenario.returnRates[0]}
                            onChange={(e) => {
                                const val = parseFloat(e.target.value);
                                const newRates = [val, val, val];
                                const newScenarios = [...input.scenarios];
                                newScenarios[sIndex] = { ...newScenarios[sIndex], returnRates: newRates, riskLevel: RiskLevel.CUSTOM };
                                onChange({ ...input, scenarios: newScenarios });
                            }}
                            className="flex-1 h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-gray-500"
                        />
                        <span className="text-[10px] font-bold text-gray-700 w-8 text-right">{scenario.returnRates[0]}%</span>
                      </div>
                    )}
                </div>
              );
            })}
        </div>
      </section>

      <button
        onClick={onCalculate}
        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold py-4 px-6 rounded-xl transition-all shadow-lg flex items-center justify-center text-lg transform hover:scale-[1.01]"
      >
        🔮 결과 확인하기
      </button>
    </div>
  );
};