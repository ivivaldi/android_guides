
import React, { useEffect, useState, useRef } from 'react';
import { CalculationResult, UserInput, RiskLevel } from '../types';
import { ResultChart } from './ResultChart';
import { getGeminiAdvice } from '../services/geminiService';
import { AdBanner } from './AdBanner';
import ReactMarkdown from 'react-markdown';

interface ResultViewProps {
  result: CalculationResult;
  input: UserInput;
  onReset: () => void;
  onInputChange: (input: UserInput) => void;
}

// Risk Presets
const RISK_PRESETS = {
    [RiskLevel.CONSERVATIVE]: 4,
    [RiskLevel.MODERATE]: 7,
    [RiskLevel.AGGRESSIVE]: 10, // Updated to 10%
    [RiskLevel.CUSTOM]: 0
};

export const ResultView: React.FC<ResultViewProps> = ({ result, input, onReset, onInputChange }) => {
  const [advice, setAdvice] = useState<string>('');
  const [loadingAdvice, setLoadingAdvice] = useState<boolean>(true);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let isMounted = true;
    
    const fetchAdvice = async () => {
      setLoadingAdvice(true);
      try {
        const text = await getGeminiAdvice(input, result);
        if (isMounted) {
          setAdvice(text);
          setLoadingAdvice(false);
        }
      } catch (e) {
        if (isMounted) setLoadingAdvice(false);
      }
    };

    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      fetchAdvice();
    }, 1500);

    return () => {
      isMounted = false;
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [input, result.summary.bestOption]);

  const bestIsDB = result.summary.bestOption.includes('DB');

  // Real-time update handlers
  const handleWageGrowthChange = (value: number) => {
    onInputChange({ ...input, expectedWageGrowthRate: value });
  };

  const handleReturnRateChange = (sIndex: number, rIndex: number, value: number) => {
    const newScenarios = [...input.scenarios];
    const newRates = [...newScenarios[sIndex].returnRates];
    newRates[rIndex] = value;
    newScenarios[sIndex] = { ...newScenarios[sIndex], returnRates: newRates, riskLevel: RiskLevel.CUSTOM };
    onInputChange({ ...input, scenarios: newScenarios });
  };

  const handleRiskLevelSelect = (scenarioIndex: number, level: RiskLevel) => {
    if (level === RiskLevel.CUSTOM) return;
    
    const rate = RISK_PRESETS[level];
    const newScenarios = [...input.scenarios];
    newScenarios[scenarioIndex] = { 
        ...newScenarios[scenarioIndex], 
        riskLevel: level,
        returnRates: [rate, rate, rate] 
    };
    onInputChange({ ...input, scenarios: newScenarios });
  };

  const handleShare = async () => {
    try {
        const jsonStr = JSON.stringify(input);
        const encoded = btoa(encodeURIComponent(jsonStr));
        const url = `${window.location.origin}${window.location.pathname}?share=${encoded}`;
        const title = `DC해마찍 - ${input.nickname || '익명'}님의 은퇴 자산 시뮬레이션`;
        const text = `최적의 선택: ${result.summary.bestOption}\n예상 은퇴 자산: ${Math.round(result.summary.scenarios.find(s=>s.label===result.summary.bestOption)?.finalAmount!/10000 || result.summary.finalDB/10000)}억원\n\n지금 바로 확인해보세요!`;

        if (navigator.share) {
            await navigator.share({
                title: title,
                text: text,
                url: url
            });
        } else {
            await navigator.clipboard.writeText(`${text}\n${url}`);
            alert('결과 링크가 클립보드에 복사되었습니다.');
        }
    } catch (e) {
        console.error("Sharing failed", e);
        alert('공유하기 기능을 사용할 수 없습니다.');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-10">
      
      {/* Header with Share */}
      <div className="flex justify-end">
          <button 
            onClick={handleShare}
            className="flex items-center space-x-1.5 bg-white/20 backdrop-blur-md text-white px-4 py-2 rounded-full text-sm font-bold hover:bg-white/30 transition-colors shadow-lg border border-white/20"
          >
             <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
             </svg>
             <span>결과 공유</span>
          </button>
      </div>

      {/* Optimal Choice Card (Visual Emphasis) */}
      <div className="relative overflow-hidden rounded-2xl shadow-2xl transform transition-all hover:scale-[1.01]">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-purple-600 to-indigo-800"></div>
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20"></div>
          <div className="relative p-6 md:p-8 text-center text-white">
              <h2 className="text-sm md:text-base font-bold text-indigo-100 mb-1 uppercase tracking-widest">최적의 은퇴 전략</h2>
              <div className="text-3xl md:text-5xl font-extrabold mb-3 drop-shadow-lg tracking-tight">
                {result.summary.bestOption}
              </div>
              <div className="inline-flex items-center bg-white/20 backdrop-blur-md rounded-full px-5 py-2 mt-1 border border-white/30 shadow-inner">
                 <span className="text-sm text-indigo-50 mr-2">예상 최종 자산</span>
                 <span className="text-xl md:text-2xl font-bold text-white">
                    {result.summary.bestOption === 'DB 유지' 
                        ? `${Math.round(result.summary.finalDB / 10000)}억 ${(result.summary.finalDB % 10000).toLocaleString()}만`
                        : `${Math.round(result.summary.scenarios.find(s => s.label === result.summary.bestOption)?.finalAmount! / 10000 || 0)}억`
                    }
                 </span>
              </div>
          </div>
      </div>

      {/* Real-time Adjustment Panel */}
      <div className="bg-gray-800/90 backdrop-blur-lg text-white p-5 rounded-2xl shadow-xl border border-white/10">
        <h3 className="text-sm font-bold text-gray-300 mb-4 flex items-center">
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
          </svg>
          실시간 시뮬레이션 조정
        </h3>
        
        <div className="space-y-5">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-gray-400">예상 임금 상승률</span>
              <span className="font-bold text-blue-300">{input.expectedWageGrowthRate}%</span>
            </div>
            <input 
              type="range" min="1" max="10" step="0.1"
              value={input.expectedWageGrowthRate}
              onChange={(e) => handleWageGrowthChange(parseFloat(e.target.value))}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
          </div>

          <div className="border-t border-gray-700 pt-3">
             <div className="space-y-4">
               {input.scenarios.map((scenario, sIndex) => {
                 const isVariable = sIndex >= 2;
                 return (
                 <div key={scenario.id} className="bg-gray-700/50 p-3 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                        <div className="text-xs font-bold text-gray-300">{scenario.label} ({scenario.switchYear}년)</div>
                        {scenario.riskLevel === RiskLevel.CUSTOM && (
                            <span className="text-[10px] text-yellow-400 border border-yellow-400 px-1 rounded">직접설정</span>
                        )}
                    </div>

                    {/* Risk Level Selector */}
                    <div className="flex space-x-1 mb-3">
                        {[RiskLevel.CONSERVATIVE, RiskLevel.MODERATE, RiskLevel.AGGRESSIVE].map((level) => {
                             const isSelected = scenario.riskLevel === level;
                             let colorClass = "";
                             if (level === RiskLevel.CONSERVATIVE) {
                                 colorClass = isSelected ? "bg-blue-600 text-white" : "bg-gray-600 text-gray-300 hover:bg-gray-500";
                             } else if (level === RiskLevel.MODERATE) {
                                 colorClass = isSelected ? "bg-green-600 text-white" : "bg-gray-600 text-gray-300 hover:bg-gray-500";
                             } else {
                                 colorClass = isSelected ? "bg-red-500 text-white" : "bg-gray-600 text-gray-300 hover:bg-gray-500";
                             }

                             return (
                                <button
                                    key={level}
                                    onClick={() => handleRiskLevelSelect(sIndex, level)}
                                    className={`flex-1 py-1 rounded text-[10px] font-medium transition-all ${colorClass}`}
                                >
                                    {level}
                                </button>
                             );
                        })}
                    </div>
                    
                    {isVariable ? (
                      <div className="grid grid-cols-3 gap-2">
                        {[0, 1, 2].map(rIndex => (
                          <div key={rIndex}>
                            <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                              <span>{rIndex===0?'0-5':rIndex===1?'6-10':'11+'}년</span>
                              <span className="text-green-400">{scenario.returnRates[rIndex]}%</span>
                            </div>
                            <input 
                              type="range" min="3" max="15" step="0.5"
                              value={scenario.returnRates[rIndex]}
                              onChange={(e) => handleReturnRateChange(sIndex, rIndex, parseFloat(e.target.value))}
                              className="w-full h-1 bg-gray-500 rounded-lg appearance-none cursor-pointer accent-green-500"
                            />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-400">수익률(Max 15%)</span>
                          <span className="font-bold text-green-400">{scenario.returnRates[0]}%</span>
                        </div>
                         <input 
                            type="range" min="3" max="15" step="0.5"
                            value={scenario.returnRates[0]}
                            onChange={(e) => {
                                const val = parseFloat(e.target.value);
                                const newRates = [val, val, val];
                                const newScenarios = [...input.scenarios];
                                newScenarios[sIndex] = { ...newScenarios[sIndex], returnRates: newRates, riskLevel: RiskLevel.CUSTOM };
                                onInputChange({ ...input, scenarios: newScenarios });
                            }}
                            className="w-full h-1 bg-gray-500 rounded-lg appearance-none cursor-pointer accent-green-500"
                        />
                      </div>
                    )}
                 </div>
               )})}
             </div>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-white p-5 rounded-2xl shadow-xl border border-white/60">
        <h3 className="text-lg font-bold text-gray-800 mb-2">자산 성장 및 생활비 지출</h3>
        <p className="text-xs text-gray-500 mb-4 bg-gray-100 p-2 rounded">
            * 붉은 점선은 물가상승률과 의료비 증가가 반영된 <span className="text-red-500 font-bold">월 필요 생활비</span>(우측 축)입니다.
            <br/>이 선보다 자산 그래프가 낮아지면 생활비가 부족하다는 의미입니다.
        </p>
        <ResultChart 
            data={result.projections} 
            scenarios={input.scenarios}
            birthYear={input.birthYear}
            retirementAge={input.retirementAge}
        />
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <div className={`p-4 rounded-xl border shadow-sm ${bestIsDB ? 'bg-blue-50 border-blue-300 ring-2 ring-blue-100' : 'bg-white border-gray-200'}`}>
            <div className="text-xs text-gray-500 font-semibold mb-1">DB 유지</div>
            <div className="text-lg font-bold text-gray-900">{Math.round(result.summary.finalDB / 10000)}억 {(result.summary.finalDB % 10000).toLocaleString()}만</div>
            <div className="text-xs text-gray-400 mt-1">세후 약 {Math.round(result.summary.finalDBAfterTax / 10000)}억</div>
        </div>

        {result.summary.scenarios.map((scenario) => {
            const isBest = result.summary.bestOption === scenario.label;
            return (
                <div key={scenario.id} className={`p-4 rounded-xl border shadow-sm ${isBest ? 'bg-green-50 border-green-300 ring-2 ring-green-100' : 'bg-white border-gray-200'}`}>
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-xs text-gray-500 font-semibold">{scenario.label}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${scenario.riskLevel === RiskLevel.AGGRESSIVE ? 'bg-red-100 text-red-600' : scenario.riskLevel === RiskLevel.CONSERVATIVE ? 'bg-blue-100 text-blue-600' : scenario.riskLevel === RiskLevel.CUSTOM ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-600'}`}>
                            {scenario.riskLevel}
                        </span>
                    </div>
                    <div className="text-lg font-bold text-gray-900">{Math.round(scenario.finalAmount / 10000)}억 {(scenario.finalAmount % 10000).toLocaleString()}만</div>
                    <div className="text-xs text-gray-400 mt-1">세후 약 {Math.round(scenario.finalAmountAfterTax / 10000)}억</div>
                    {scenario.depletionAge !== '유지' && (
                        <div className="text-[10px] text-red-500 font-bold mt-1">🚨 {scenario.depletionAge}세 고갈</div>
                    )}
                </div>
            );
        })}
      </div>
      
      {/* Middle Ad Slot */}
      <AdBanner className="my-2 h-20 bg-gray-50 rounded-lg" />

      {/* Rich Fairy Analysis */}
      <div className="bg-white p-6 rounded-2xl border border-indigo-100 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-32 w-32 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.465 5.05l-.708-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" />
            </svg>
        </div>
        <div className="border-b border-gray-100 pb-3 mb-4 flex items-center relative z-10">
             <span className="text-2xl mr-3 bg-yellow-100 p-2 rounded-full border border-yellow-300">🧚‍♀️</span>
             <h3 className="text-lg font-bold text-gray-900">갑부요정의 자산 진단</h3>
        </div>
        
        {loadingAdvice ? (
            <div className="flex flex-col items-center justify-center py-8 space-y-3">
                <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                <p className="text-sm text-gray-500">갑부요정이 계산기를 두드리고 있어요...</p>
            </div>
        ) : (
            <div className="prose prose-sm prose-indigo max-w-none text-gray-700 leading-relaxed relative z-10">
                <ReactMarkdown
                  components={{
                    h3: ({node, ...props}) => <h3 className="text-base font-bold text-indigo-900 mt-6 mb-3 flex items-center border-b border-indigo-100 pb-2" {...props} />,
                    p: ({node, ...props}) => <p className="mb-4 bg-white/80 p-4 rounded-xl border border-indigo-50 shadow-sm text-sm text-gray-700 leading-relaxed hover:shadow-md transition-all" {...props} />,
                    strong: ({node, ...props}) => <span className="font-bold text-indigo-700 bg-indigo-50 px-1 rounded" {...props} />,
                    ul: ({node, ...props}) => <ul className="list-none space-y-2 mb-4" {...props} />,
                    li: ({node, ...props}) => (
                      <li className="flex items-start bg-white/60 p-3 rounded-lg border border-indigo-50 shadow-sm" {...props}>
                        <span className="mr-2 mt-0.5 text-indigo-400 font-bold">•</span>
                        <span className="flex-1">{props.children}</span>
                      </li>
                    ),
                  }}
                >
                  {advice}
                </ReactMarkdown>
            </div>
        )}
      </div>

      <button
        onClick={onReset}
        className="w-full bg-white/50 hover:bg-white/80 backdrop-blur text-gray-800 font-bold py-4 px-4 rounded-xl transition-colors shadow border border-white/40"
      >
        조건 다시 설정하기
      </button>
    </div>
  );
};
